---
# Files in this folder represent a Widget Page (homepage)
type: widget_page

# Homepage is headless, other widget pages are not.
headless: true
---
